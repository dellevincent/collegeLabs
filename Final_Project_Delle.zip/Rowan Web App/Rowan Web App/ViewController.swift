//
//  ViewController.swift
//  Rowan Web App
//
//  Created by Vincent Delle on 12/7/20.
//

import UIKit
import WebKit

class ViewController: UIViewController, WKNavigationDelegate {
 
    
    var webView: WKWebView!
    var progressView: UIProgressView!
    
    var websites = ["rowan.edu", "rowan.edu/registrar", "rowan.edu/bursar", "rowan.edu/reslife", "rowan.edu/rsn", "sites.rowan.edu/parentsfamily/family-weekend/index.html", "rucsm.org/cs/faculty/robinson/index.php", "facebook.com/RowanUniversity", "twitter.com/RowanUniversity"]
    
    override func loadView() {
        webView = WKWebView()
        webView.navigationDelegate = self
        view = webView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let url = URL(string: "https://" + websites[0])!
            webView.load(URLRequest(url: url))
            webView.allowsBackForwardNavigationGestures = true
            navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Open", style: .plain, target: self, action: #selector(openTapped))
        
        progressView = UIProgressView(progressViewStyle: .default)
        progressView.sizeToFit()
        let progressButton = UIBarButtonItem(customView: progressView)
        let spacer = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let refresh = UIBarButtonItem(barButtonSystemItem: .refresh, target: webView, action: #selector(webView.reload))
        let back = UIBarButtonItem(barButtonSystemItem: .rewind, target: webView, action: #selector(webView.goBack))
        let forward = UIBarButtonItem(barButtonSystemItem: .fastForward, target: webView, action: #selector(webView.goForward))
        toolbarItems = [progressButton, spacer, back, forward, refresh]
        navigationController?.isToolbarHidden = false
        webView.addObserver(self, forKeyPath: #keyPath(WKWebView.estimatedProgress), options: .new, context: nil)
        
    }
    
    
    @objc func openTapped() {
        let ac = UIAlertController(title: "Open page...", message: nil, preferredStyle: .actionSheet)
        for i in 0...websites.count - 1 {
            ac.addAction(UIAlertAction(title: websites[i], style: .default, handler: openPage)) }
            ac.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            ac.popoverPresentationController?.barButtonItem = self.navigationItem.rightBarButtonItem
            present(ac, animated: true)
        
    }
    
    func openPage(action: UIAlertAction) {
        let url = URL(string: "https://" + action.title!)!
        webView.load(URLRequest(url: url))
        
    }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        title = webView.title
        
    }
    
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if let host = navigationAction.request.url?.host {
    // Your if statement to check to see if host contains a string equal to the websites in the array
            if host.contains("rowan.edu") || host.contains("twitter.com")  || host.contains("rucsm.org")
                || host.contains("facebook.com") || host.contains("sites.rowan.edu"){
                    decisionHandler(.allow)
                    return
            }

        }
        decisionHandler(.cancel)
        
    }

    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
    if keyPath == "estimatedProgress" {
    progressView.progress = Float(webView.estimatedProgress) }
    }

}

