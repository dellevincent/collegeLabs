var mysql = require('mysql');
const axios = require('axios').default;

var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "Stormy123!",
    database:"capstone_db"
});

con.connect(function (err) {
    if (err) throw err;
    console.log("Connected!");
});

con.query("SELECT * FROM Song", function (err, result, fields) {
    if (err) throw err;
    console.log(result);
});

// con.query("INSERT INTO Song (TITLE, DESCRIPTION) VALUES('titleofsong','descripofsong')", function (err, result, fields) {
//     if (err) throw err;
//     console.log(result);
// });


// https://youtube.googleapis.com/youtube/v3/search/?part=snippet&q=ariana&key=AIzaSyAp2UvYJhMV1tzDrRhZq0U23capjS1wtPE&order=viewCount
// makes web request, works like a web broswer inside code
axios.get('https://youtube.googleapis.com/youtube/v3/search/?part=snippet&q=ariana&key=AIzaSyACbY7C0QjM9YEr822Yj-eRz8aW8IOUecw&order=viewCount')
    .then((response) => {
        //console.log(response)
        console.log(response.data.items)
        response.data.items.forEach(function(val){
            console.log('valis; ', val.snippet)
           // con.query(`INSERT INTO Song (TITLE, DESCRIPTION) VALUES("${val.snippet.title}", "${val.snippet.description}")`, function (err, result, fields) {
            con.query(`INSERT INTO Song (TITLE, DESCRIPTION) VALUES(?, ?)`, [val.snippet.title, val.snippet.description], function (err, result, fields) {
                if (err) throw err;
                console.log(result);
            });
        })
    })

axios.get('http://ws.audioscrobbler.com/2.0/?method=chart.gettopartists&api_key=bbe96a57fc07ddfa261039b686d758be&format=json')
    .then((response) => {
        //console.log(response)
        console.log(response.data.items)
        response.data.items.forEach(function(val){
            console.log('valis; ', val.snippet)
            // con.query(`INSERT INTO Song (TITLE, DESCRIPTION) VALUES("${val.snippet.title}", "${val.snippet.description}")`, function (err, result, fields) {
            con.query(`INSERT INTO Song (TITLE, DESCRIPTION) VALUES(?, ?)`, [val.snippet.title, val.snippet.description], function (err, result, fields) {
                if (err) throw err;
                console.log(result);
            });
        })
    })




