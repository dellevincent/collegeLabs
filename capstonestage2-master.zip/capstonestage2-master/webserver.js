const Koa = require('koa');
const Mount = require('koa-mount');
const Serve = require('koa-static');
const Router = require('koa-router');
const axios = require('axios').default;
const schedule = require('node-schedule');

var mysql = require('mysql');

var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "Stormy123!",
    database: "capstone_db"
});

con.connect(function (err) {
    if (err) throw err;
    console.log("Connected!");
});

const app = new Koa();
const router = new Router();

router.get('/lastFM', async (ctx, next) => {
    // ctx.router available
    // await axios.get('http://ws.audioscrobbler.com/2.0/?method=chart.gettopartists&api_key=bbe96a57fc07ddfa261039b686d758be&format=json')
    //     .then((response) => {
    //         console.log(response)
    //         console.log(response.data.items)
    //         ctx.body = response.data
    //     })

    let result = await top20query()
    console.log(result)
    //ctx.body = result

    let result2 = await topTracksquery()
    console.log(result2)
    ctx.body = {
         top20: result, topTracks: result2
    }
});

const youtubeURL = 'https://youtube.googleapis.com/youtube/v3/search/?part=snippet'
const apiKey = 'AIzaSyACbY7C0QjM9YEr822Yj-eRz8aW8IOUecw'

router.get('/videos', async (ctx, next) => {
    console.log(ctx.query.artist)
    let artist = ctx.query.artist
    let query = `${youtubeURL}&q=${artist}&key=${apiKey}&order=viewCount`

    await axios.get(query)
        .then((response) => {
            //console.log(response)
            console.log(response.data.items)
            ctx.body = response.data
        })
})

app.use(router.routes())
    .use(router.allowedMethods())
    .use(Mount("/app", Serve("./app")))

app.listen(3000, () => console.log('running on port 3000'))

function top20query() {
    return new Promise((resolve, reject) => {
        con.query('SELECT * FROM topartists', function (err, results, fields) {
            if (err) {
                throw err
            }

            resolve(results)
            // console.log('The solution is: ', results[0].solution);
        });
    })
}

function topTracksquery() {
    return new Promise((resolve, reject) => {
        con.query('SELECT * FROM toptracks', function (err, results, fields) {
            if (err) {
                throw err
            }

            resolve(results)
            // console.log('The solution is: ', results[0].solution);
        });
    })
}