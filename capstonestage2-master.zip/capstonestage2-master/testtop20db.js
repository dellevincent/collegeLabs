const axios = require('axios').default;
var mysql = require('mysql');

var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "Stormy123!",
    database: "capstone_db"
});

con.connect(function (err) {
    if (err) throw err;
    console.log("Connected!");
});

axios.get('http://ws.audioscrobbler.com/2.0/?method=chart.gettopartists&api_key=bbe96a57fc07ddfa261039b686d758be&format=json')
    //axios.get('https://youtube.googleapis.com/youtube/v3/search/?part=snippet&q=ariana&key=AIzaSyACbY7C0QjM9YEr822Yj-eRz8aW8IOUecw&order=viewCount')
    .then((response) => {
        //    console.log(response)
        console.log(response.data.artists.artist)
        con.query('delete from topartists', function (err, result, fields) {
            if (err) throw err;
            console.log(result);
        })

        response.data.artists.artist.filter((it, i) => i < 20).forEach(function (val, i) {
            console.log(val)
            con.query(`INSERT INTO topartists (POSITION, ARTIST, PLAYCOUNT, LISTENERS)
                       VALUES (?, ?, ?, ?)`,
                [i+1, val.name, val.playcount, val.listeners], function (err, result, fields) {
                    if (err) throw err;
                    console.log(result);
                });
        })
        //ctx.body = response.data
    })

axios.get('http://ws.audioscrobbler.com/2.0/?method=chart.gettoptracks&api_key=bbe96a57fc07ddfa261039b686d758be&format=json')
    //axios.get('https://youtube.googleapis.com/youtube/v3/search/?part=snippet&q=ariana&key=AIzaSyACbY7C0QjM9YEr822Yj-eRz8aW8IOUecw&order=viewCount')
    .then((response) => {
        //    console.log(response)
        console.log(response.data.tracks.track)
        con.query('delete from toptracks', function (err, result, fields) {
            if (err) throw err;
            console.log(result);
       })

        response.data.tracks.track.filter((it, i) => i < 20).forEach(function (val, i) {
            console.log(val)
            con.query(`INSERT INTO toptracks (POSITION, TRACK, ARTIST, PLAYCOUNT, LISTENERS, DURATION)
                       VALUES (?, ?, ?, ?, ?, ?)`,
                [i+1, val.name, val.artist.name, val.playcount, val.listeners, val.duration], function (err, result, fields) {
                    if (err) throw err;
                    console.log(result);
                });
        })
        //ctx.body = response.data
    })