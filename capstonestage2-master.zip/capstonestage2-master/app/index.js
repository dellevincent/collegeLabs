console.log("this is a test")

// line 11 makes request to web server endpoint /videos with selected artist param
function createItem(record, i) {
    // console.log(i, record)
    return m('div.ui.link.item', {
        onclick: () => {
            console.log("record", record)
            let artist = record.artist
            let query = `artist=${artist}`
            m.request({
                url: `/videos?${query}`,
            }).then(function (result) {
                console.log(result)
                data.videos = result
            })
        }
    }, [
        //    m('img.ui.avatar.image', {src: record.image[1]['#text']}),
        m('div.content', [
            m('.header', record.artist),
            `playcount: ${record.playcount}, listeners: ${record.listeners}`,
        ])

    ])
}

function createItem2(record, i) {
    // console.log(i, record)
    return m('div.ui.link.item', {},
        [
            //   m('img.ui.avatar.image', {src: record.image[1]['#text']}),
            m('div.content', [
                m('.header', record.track),
                `position: ${record.position}, artist: ${record.artist}, playcount: ${record.playcount}, listeners: ${record.listeners}, duration: ${record.duration}`,
            ])

        ])
}

let data = {
    videos: {items: []}
}
const Videos = () => {
    return {
        view: () => {
            return m('div.ui.divided.list.topVideos', data.videos.items.map((video) => {
                return m("div.item", {
                    onclick: () => {
                        console.log(video)
                        data.showEmbedded = video
                    }
                }, [
                    video.snippet.title,

                ])
            }))
        }
    }
}
const Top20 = () => {
    return {
        view: () => {
            return m('div.top20', [
                m("h1.header", "Top 20 Artists"),
                m('div.ui.divided.list', data.artists.map(createItem))
            ])
        }
    }
}

const TopTracks = () => {
    return {
        view: () => {
            return m('div.topTracks', [
                m("h1.header", "Top 20 Tracks"),
                m('div.ui.divided.list', data.tracks.map(createItem2))
            ])
        }
    }
}

const App = () => {
    return {
        view: () => {
            let {id} = data.showEmbedded
            return [
                m('div.top-container', [
                    m(Top20),
                    m(TopTracks),
                ]),

                m(Videos),

                id && m('div', [
                    m('iframe', {
                        width:"560", height:"315",
                        src:`https://www.youtube.com/embed/${id.videoId}`
                    })
                ])
            ]
        }
    }
}
//m.request is where the app starts
// browser goes to web server /lastFM endpoint
// web server makes axios request to lastFM
// web server returns axios results to browser
// on line 64 we assign results to a data object
// on line 65 we mount an app that knows how to display results
m.request({
    url: "/lastFM",
})
    .then(function (result) {
        console.log(result)
        data.artists = result.top20
        data.tracks = result.topTracks
        data.showEmbedded = {}
        m.mount(document.body, App)
    })

// m.request({
//     url: "/lastFM",
// })
//     .then(function (result2) {
//         console.log(result2)
//         data.tracks = result2
//         m.mount(document.body, App)
//     })
