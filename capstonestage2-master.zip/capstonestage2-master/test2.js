//https://youtube.googleapis.com/youtube/v3/search/?part=snippet&q=ariana&key=AIzaSyACbY7C0QjM9YEr822Yj-eRz8aW8IOUecw&order=viewCount
let youtubeURL = 'https://youtube.googleapis.com/youtube/v3/search/?part=snippet'
let artist = 'ariana grande', apiKey = 'AIzaSyACbY7C0QjM9YEr822Yj-eRz8aW8IOUecw'
let query = `${youtubeURL}&q=${artist}&key=${apiKey}&order=viewCount`
console.log(encodeURI(query))
console.log(query)