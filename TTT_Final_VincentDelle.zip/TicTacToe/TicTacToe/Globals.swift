//
//  globals.swift
//  TicTacToe
//
//  Created by Vincent Delle10/29/20.
//

import UIKit

class Globals {
    
    var  humanWins: Int  = 0
    var  computerWins: Int = 0
    var gameTies: Int = 0
    
    
    
    class var sharedManager: Globals {
        struct Static {
            static let instance = Globals()
    }
        return Static.instance
    }
}
