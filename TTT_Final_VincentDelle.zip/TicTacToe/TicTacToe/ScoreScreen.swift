//
//  ScoreScreen.swift
//  TicTacToe
//
//  Created by vincent Delle on 10/29/20.
//

import UIKit

class ScoreScreen: UIViewController{
    
    @IBOutlet weak var hScore: UILabel!
    @IBOutlet weak var cScore: UILabel!
    @IBOutlet weak var gTies: UILabel!
    
    @IBAction func reset(_ sender: Any) {
        Globals.sharedManager.humanWins = 0
        Globals.sharedManager.computerWins = 0
        Globals.sharedManager.gameTies = 0
        
      
        self.hScore.text = "0"
        self.cScore.text = "0"
        self.gTies.text = "0"
        
        
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hScore.text = String(Globals.sharedManager.humanWins)
        self.cScore.text = String(Globals.sharedManager.computerWins)
        self.gTies.text = String(Globals.sharedManager.gameTies)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.hScore.text = String(Globals.sharedManager.humanWins)
        self.cScore.text = String(Globals.sharedManager.computerWins)
        self.gTies.text = String(Globals.sharedManager.gameTies)
    }
  
    override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            // Dispose of any resources that can be recreated.
    }
}
