//
//  ViewController.swift
//  TicTacToe
//
//  Created by Vincent Delle on 9/30/20.
//

import UIKit

class GameScreen: UIViewController {
    
    @IBOutlet weak var s1: UIImageView!
    @IBOutlet weak var s2: UIImageView!
    @IBOutlet weak var s3: UIImageView!
    @IBOutlet weak var s4: UIImageView!
    @IBOutlet weak var s5: UIImageView!
    @IBOutlet weak var s6: UIImageView!
    @IBOutlet weak var s7: UIImageView!
    @IBOutlet weak var s8: UIImageView!
    @IBOutlet weak var s9: UIImageView!
    
    var mBoardArray:[UIImageView]=[]
    
    @IBOutlet weak var whoseTurn: UILabel!
    
    
    let HUMAN_PLAYER = "X"
    let COMPUTER_PLAYER = "O"
    var board: [String] = ["0","1","2","3","4","5","6","7","8"]
    let BOARD_SIZE = 9
    var turn = "X"
    var win = 0
    var move = -1
    
    @IBAction func NewGame(_ sender: Any) {
        
        for i in 0...BOARD_SIZE-1{
            mBoardArray[i].image = nil
        }
        print("TTT_ACTIVITY: Starting New Game")
        turn = HUMAN_PLAYER
        self.whoseTurn.text = "Human’s Turn"
        board = ["0", "1", "2", "3", "4", "5", "6","7", "8"]
        win=0
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        mBoardArray.append(s1)
        mBoardArray.append(s2)
        mBoardArray.append(s3)
        mBoardArray.append(s4)
        mBoardArray.append(s5)
        mBoardArray.append(s6)
        mBoardArray.append(s7)
        mBoardArray.append(s8)
        mBoardArray.append(s9)
        self.whoseTurn.text = "Human’s Turn"
       
        let tapGesture1 = UITapGestureRecognizer(target: self, action:
                    #selector(GameScreen.img1Clicked))
        tapGesture1.numberOfTapsRequired = 1
        s1.addGestureRecognizer(tapGesture1)
        
        let tapGesture2 = UITapGestureRecognizer(target: self, action:
                    #selector(GameScreen.img2Clicked))
        tapGesture2.numberOfTapsRequired = 1
        s2.addGestureRecognizer(tapGesture2)
        
        let tapGesture3 = UITapGestureRecognizer(target: self, action:
                    #selector(GameScreen.img3Clicked))
        tapGesture3.numberOfTapsRequired = 1
        s3.addGestureRecognizer(tapGesture3)
        
        let tapGesture4 = UITapGestureRecognizer(target: self, action:
                    #selector(GameScreen.img4Clicked))
        tapGesture4.numberOfTapsRequired = 1
        
        s4.addGestureRecognizer(tapGesture4)
        
        let tapGesture5 = UITapGestureRecognizer(target: self, action:
                    #selector(GameScreen.img5Clicked))
        tapGesture5.numberOfTapsRequired = 1
        s5.addGestureRecognizer(tapGesture5)
        
        let tapGesture6 = UITapGestureRecognizer(target: self, action:
                    #selector(GameScreen.img6Clicked))
        tapGesture6.numberOfTapsRequired = 1
        s6.addGestureRecognizer(tapGesture6)
        
        let tapGesture7 = UITapGestureRecognizer(target: self, action:
                    #selector(GameScreen.img7Clicked))
        tapGesture7.numberOfTapsRequired = 1
        s7.addGestureRecognizer(tapGesture7)
        
        let tapGesture8 = UITapGestureRecognizer(target: self, action:
                    #selector(GameScreen.img8Clicked))
        tapGesture8.numberOfTapsRequired = 1
        s8.addGestureRecognizer(tapGesture8)
        
        let tapGesture9 = UITapGestureRecognizer(target: self, action:
                    #selector(GameScreen.img9Clicked))
        tapGesture9.numberOfTapsRequired = 1
        s9.addGestureRecognizer(tapGesture9)
    }
    
    override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            // Dispose of any resources that can be recreated.
    }
    
    @objc func img1Clicked(){
     // This code is for testing the GUI, will change in real game code
    if(win==0){
        if(turn == HUMAN_PLAYER &&  board[0] != HUMAN_PLAYER && board[0] != COMPUTER_PLAYER){
            s1.image = #imageLiteral(resourceName: "x_img.png")
            board[0] = HUMAN_PLAYER
            turn = COMPUTER_PLAYER
            self.whoseTurn.text = "Computer’s Turn"
            print("TTT_ACTIVITY: ")
            displayBoard()
            checkForWinner()
            showWinStatus()
            
            if(win==0){
                getComputerMove()
                turn = self.HUMAN_PLAYER
                self.whoseTurn.text = "Human's Turn"
                displayBoard()
                checkForWinner()
                showWinStatus()
            }
        }
      }
    }
    
    @objc func img2Clicked(){
     // This code is for testing the GUI, will change in real game code
        if(win==0){
            if(turn == HUMAN_PLAYER && board[1] != HUMAN_PLAYER && board[1] != COMPUTER_PLAYER){
                s2.image = #imageLiteral(resourceName: "x_img.png")
                board[1] = HUMAN_PLAYER
                turn = COMPUTER_PLAYER
                self.whoseTurn.text = "Computer’s Turn"
                print("TTT_ACTIVITY: ")
                displayBoard()
                checkForWinner()
                showWinStatus()
                
                if(win==0){
                    getComputerMove()
                    turn = self.HUMAN_PLAYER
                    self.whoseTurn.text = "Human's Turn"
                    displayBoard()
                    checkForWinner()
                    showWinStatus()
                }
            }
        }
    }
    
    @objc func img3Clicked(){
     // This code is for testing the GUI, will change in real game code
        if(win==0){
            if(turn == HUMAN_PLAYER && board[2] != HUMAN_PLAYER && board[2] != COMPUTER_PLAYER){
                s3.image = #imageLiteral(resourceName: "x_img.png")
                board[2] = HUMAN_PLAYER
                turn = COMPUTER_PLAYER
                self.whoseTurn.text = "Computer’s Turn"
                print("TTT_ACTIVITY: ")
                displayBoard()
                checkForWinner()
                showWinStatus()
                
                if(win==0){
                    getComputerMove()
                    turn = self.HUMAN_PLAYER
                    self.whoseTurn.text = "Human's Turn"
                    displayBoard()
                    checkForWinner()
                    showWinStatus()
                }
            }
        }
    }
    
    @objc func img4Clicked(){
     // This code is for testing the GUI, will change in real game code
        if(win==0){
            if(turn == HUMAN_PLAYER && board[3] != HUMAN_PLAYER && board[3] != COMPUTER_PLAYER){
                s4.image = #imageLiteral(resourceName: "x_img.png")
                board[3] = HUMAN_PLAYER
                turn = COMPUTER_PLAYER
                self.whoseTurn.text = "Computer’s Turn"
                print("TTT_ACTIVITY: ")
                displayBoard()
                checkForWinner()
                showWinStatus()
                
                if(win==0){
                    getComputerMove()
                    turn = self.HUMAN_PLAYER
                    self.whoseTurn.text = "Human's Turn"
                    displayBoard()
                    checkForWinner()
                    showWinStatus()
                }
            }
          }
    }
    
    @objc func img5Clicked(){
     // This code is for testing the GUI, will change in real game code
        if(win==0){
            if(turn == HUMAN_PLAYER && board[4] != HUMAN_PLAYER && board[4] != COMPUTER_PLAYER){
                s5.image = #imageLiteral(resourceName: "x_img.png")
                board[4] = HUMAN_PLAYER
                turn = COMPUTER_PLAYER
                self.whoseTurn.text = "Computer’s Turn"
                print("TTT_ACTIVITY: ")
                displayBoard()
                checkForWinner()
                showWinStatus()
                
                if(win==0){
                    getComputerMove()
                    turn = self.HUMAN_PLAYER
                    self.whoseTurn.text = "Human's Turn"
                    displayBoard()
                    checkForWinner()
                    showWinStatus()
                }
            }
        }
    }
    
    @objc func img6Clicked(){
     // This code is for testing the GUI, will change in real game code
        if(win==0){
            if(turn == HUMAN_PLAYER && board[5] != HUMAN_PLAYER && board[5] != COMPUTER_PLAYER){
                s6.image = #imageLiteral(resourceName: "x_img.png")
                board[5] = HUMAN_PLAYER
                turn = COMPUTER_PLAYER
                self.whoseTurn.text = "Computer’s Turn"
                print("TTT_ACTIVITY: ")
                displayBoard()
                checkForWinner()
                showWinStatus()
                
                if(win==0){
                    getComputerMove()
                    turn = self.HUMAN_PLAYER
                    self.whoseTurn.text = "Human's Turn"
                    displayBoard()
                    checkForWinner()
                    showWinStatus()
                }
            }
        }
    }
    
    @objc func img7Clicked(){
     // This code is for testing the GUI, will change in real game code
        if(win==0){
            if(turn == HUMAN_PLAYER && board[6] != HUMAN_PLAYER && board[6] != COMPUTER_PLAYER){
                s7.image = #imageLiteral(resourceName: "x_img.png")
                board[6] = HUMAN_PLAYER
                turn = COMPUTER_PLAYER
                self.whoseTurn.text = "Computer’s Turn"
                print("TTT_ACTIVITY: ")
                displayBoard()
                checkForWinner()
                showWinStatus()
                
                if(win==0){
                    getComputerMove()
                    turn = self.HUMAN_PLAYER
                    self.whoseTurn.text = "Human's Turn"
                    displayBoard()
                    checkForWinner()
                    showWinStatus()
                }
            }
        }
    }
    
    @objc func img8Clicked(){
     // This code is for testing the GUI, will change in real game code
        if(win==0){
            if(turn == HUMAN_PLAYER && board[7] != HUMAN_PLAYER &&  board[7] != COMPUTER_PLAYER){
                s8.image = #imageLiteral(resourceName: "x_img.png")
                board[7] = HUMAN_PLAYER
                turn = COMPUTER_PLAYER
                self.whoseTurn.text = "Computer’s Turn"
                print("TTT_ACTIVITY: ")
                displayBoard()
                checkForWinner()
                showWinStatus()
                
                if(win==0){
                    getComputerMove()
                    turn = self.HUMAN_PLAYER
                    self.whoseTurn.text = "Human's Turn"
                    displayBoard()
                    checkForWinner()
                    showWinStatus()
                }
            }
        }
    }
    
    @objc func img9Clicked(){
     // This code is for testing the GUI, will change in real game code
        if(win==0){
            if(turn == HUMAN_PLAYER &&  board[8] != HUMAN_PLAYER &&  board[8] != COMPUTER_PLAYER){
                s9.image = #imageLiteral(resourceName: "x_img.png")
                board[8] = HUMAN_PLAYER
                turn = COMPUTER_PLAYER
                self.whoseTurn.text = "Computer’s Turn"
                print("TTT_ACTIVITY: ")
                displayBoard()
                checkForWinner()
                showWinStatus()
                
                if(win==0){
                    getComputerMove()
                    turn = self.HUMAN_PLAYER
                    self.whoseTurn.text = "Human's Turn"
                    displayBoard()
                    checkForWinner()
                    showWinStatus()
                    
                }
            }
        }
    }
    func displayBoard()
    {
        print()
        print(board[0] + " | " + board[1] + " | " + board[2])
        print("-----------")
        print(board[3] + " | " + board[4] + " | " + board[5])
        print("-----------")
        print(board[6] + " | " + board[7] + " | " + board[8]);
        print();
    }
    
    func showWinStatus(){
        if (win==1){
            print("It's a tie")
            whoseTurn.text="Tie!!!"
        }
        else if(win==2){
            print(HUMAN_PLAYER + "wins")
            whoseTurn.text="Human Wins !!!"
        }
        else if(win==3){
            print(COMPUTER_PLAYER + "wins")
            whoseTurn.text="Computer Wins !!!"
        }
        else{
            print("There is a logical problem")
        }
    }
    
    func getComputerMove(){
        
        for index in 0...8{
                if(board[index] != HUMAN_PLAYER && board[index] != COMPUTER_PLAYER){
                    let curr = board[index]
                    board[index]=COMPUTER_PLAYER
                    checkForWinner()
    
                    if(win == 3){
                        mBoardArray[index].image=#imageLiteral(resourceName: "o_img.png")
                        return
                    }
                    else{
                        board[index]=curr
                    }
                }
        }
        for index in 0...8{
            if(board[index] != HUMAN_PLAYER && board[index] != COMPUTER_PLAYER){
                let curr = board[index]
                board[index]=HUMAN_PLAYER
                checkForWinner()
                if(win==2){
                    board[index]=COMPUTER_PLAYER
                    mBoardArray[index].image=#imageLiteral(resourceName: "o_img.png")
                    return
                }
                else{
                    board[index]=curr
                }
            }
        }
        repeat{
            move = Int.random(in: 0..<9)
        }
        while(board[move] == HUMAN_PLAYER || board[move] == COMPUTER_PLAYER)
       
        board[move]=COMPUTER_PLAYER
        mBoardArray[move].image=#imageLiteral(resourceName: "o_img.png")
    }
    
    func checkForWinner(){
        for index in stride(from: 0, through: 6, by: 3){
            if(board[index] == HUMAN_PLAYER && board[index+1] == HUMAN_PLAYER && board[index+2] == HUMAN_PLAYER){
               win = 2
                return
            }
            if(board[index] == COMPUTER_PLAYER && board[index+1] == COMPUTER_PLAYER && board[index+2] == COMPUTER_PLAYER){
               win = 3
                return
            }
        }
        for index in 0...2{
            if(board[index] == HUMAN_PLAYER && board[index+3] == HUMAN_PLAYER && board[index+6] == HUMAN_PLAYER){
                win = 2
                return
            }
            if(board[index] == COMPUTER_PLAYER && board[index+3] == COMPUTER_PLAYER && board[index+6] == COMPUTER_PLAYER){
                win = 3
                return
            }
        }
        if(board[0] == HUMAN_PLAYER && board[4] == HUMAN_PLAYER && board[8] == HUMAN_PLAYER || board[2] == HUMAN_PLAYER && board[4] == HUMAN_PLAYER && board[6] == HUMAN_PLAYER){
            win = 2
            return
        }
        if(board[0] == COMPUTER_PLAYER && board[4] == COMPUTER_PLAYER && board[8] == COMPUTER_PLAYER || board[2] == COMPUTER_PLAYER && board[4] == COMPUTER_PLAYER && board[6] == COMPUTER_PLAYER){
            win = 3
            return
        }
        
        for index in 0...8{
            if(board[index] != HUMAN_PLAYER && board[index] != COMPUTER_PLAYER){
                win = 0
                return
            }
        }
        win=1
  }
}
