//
//  ViewController.swift
//  TicTacToe
//
//  Created by Vincent Delle on 9/30/20.
//

import UIKit
import AVFoundation

class GameScreen: UIViewController {
    
    var sound1: AVAudioPlayer?
    var sound2: AVAudioPlayer?
    
    var gameDifficulty:Int!
    
    @IBOutlet weak var s1: UIImageView!
    @IBOutlet weak var s2: UIImageView!
    @IBOutlet weak var s3: UIImageView!
    @IBOutlet weak var s4: UIImageView!
    @IBOutlet weak var s5: UIImageView!
    @IBOutlet weak var s6: UIImageView!
    @IBOutlet weak var s7: UIImageView!
    @IBOutlet weak var s8: UIImageView!
    @IBOutlet weak var s9: UIImageView!
    
    var mBoardArray:[UIImageView]=[]
    
    @IBOutlet weak var whoseTurn: UILabel!
    
    
    let HUMAN_PLAYER = "X"
    let COMPUTER_PLAYER = "O"
    var board: [String] = ["0","1","2","3","4","5","6","7","8"]
    let BOARD_SIZE = 9
    var turn = "X"
    var win = 0
    var move = -1
    
    @IBAction func NewGame(_ sender: Any) {
        
        for i in 0...BOARD_SIZE-1{
            mBoardArray[i].image = nil
        }
        print("TTT_ACTIVITY: Starting New Game")
        turn = HUMAN_PLAYER
        self.whoseTurn.text = "Human’s Turn"
        board = ["0", "1", "2", "3", "4", "5", "6","7", "8"]
        win=0
    }
    
    @IBAction func gameSetting(_ sender: Any) {
        let easy = "Easy"
        let medium = "Medium"
        let hard = "Hard"
        
        let ac = UIAlertController(title: "Game Settings", message: "Select the Difficulty Level", preferredStyle: .actionSheet)
        let easyAction = UIAlertAction(title: easy, style: .default, handler: { action in
        self.setDifficulty(difficulty: 1) })
        ac.addAction(easyAction)
        let mediumAction = UIAlertAction(title: medium, style: .default, handler: { action in
        self.setDifficulty(difficulty: 2) })
        ac.addAction(mediumAction)
        let hardAction = UIAlertAction(title: hard, style: .default, handler: { action in
        self.setDifficulty(difficulty: 3) })
        ac.addAction(hardAction)
        present(ac, animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        mBoardArray.append(s1)
        mBoardArray.append(s2)
        mBoardArray.append(s3)
        mBoardArray.append(s4)
        mBoardArray.append(s5)
        mBoardArray.append(s6)
        mBoardArray.append(s7)
        mBoardArray.append(s8)
        mBoardArray.append(s9)
        self.whoseTurn.text = "Human’s Turn"
       
        let tapGesture1 = UITapGestureRecognizer(target: self, action:
                    #selector(GameScreen.img1Clicked))
        tapGesture1.numberOfTapsRequired = 1
        s1.addGestureRecognizer(tapGesture1)
        
        let tapGesture2 = UITapGestureRecognizer(target: self, action:
                    #selector(GameScreen.img2Clicked))
        tapGesture2.numberOfTapsRequired = 1
        s2.addGestureRecognizer(tapGesture2)
        
        let tapGesture3 = UITapGestureRecognizer(target: self, action:
                    #selector(GameScreen.img3Clicked))
        tapGesture3.numberOfTapsRequired = 1
        s3.addGestureRecognizer(tapGesture3)
        
        let tapGesture4 = UITapGestureRecognizer(target: self, action:
                    #selector(GameScreen.img4Clicked))
        tapGesture4.numberOfTapsRequired = 1
        
        s4.addGestureRecognizer(tapGesture4)
        
        let tapGesture5 = UITapGestureRecognizer(target: self, action:
                    #selector(GameScreen.img5Clicked))
        tapGesture5.numberOfTapsRequired = 1
        s5.addGestureRecognizer(tapGesture5)
        
        let tapGesture6 = UITapGestureRecognizer(target: self, action:
                    #selector(GameScreen.img6Clicked))
        tapGesture6.numberOfTapsRequired = 1
        s6.addGestureRecognizer(tapGesture6)
        
        let tapGesture7 = UITapGestureRecognizer(target: self, action:
                    #selector(GameScreen.img7Clicked))
        tapGesture7.numberOfTapsRequired = 1
        s7.addGestureRecognizer(tapGesture7)
        
        let tapGesture8 = UITapGestureRecognizer(target: self, action:
                    #selector(GameScreen.img8Clicked))
        tapGesture8.numberOfTapsRequired = 1
        s8.addGestureRecognizer(tapGesture8)
        
        let tapGesture9 = UITapGestureRecognizer(target: self, action:
                    #selector(GameScreen.img9Clicked))
        tapGesture9.numberOfTapsRequired = 1
        s9.addGestureRecognizer(tapGesture9)
        
        gameDifficulty = 1
    }
    
    override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            // Dispose of any resources that can be recreated.
    }
    
    @objc func img1Clicked(){
     // This code is for testing the GUI, will change in real game code
    if(win==0){
        if(turn == HUMAN_PLAYER &&  board[0] != HUMAN_PLAYER && board[0] != COMPUTER_PLAYER){
            s1.image = #imageLiteral(resourceName: "x_img.png")
            playSound1()
            board[0] = HUMAN_PLAYER
            turn = COMPUTER_PLAYER
            self.whoseTurn.text = "Computer’s Turn"
            print("TTT_ACTIVITY: ")
            displayBoard()
            checkForWinner()
            showWinStatus()
            
            if(win==0){
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5){
                    self.getComputerMove()
                    self.turn = self.HUMAN_PLAYER
                    self.whoseTurn.text = "Human's Turn"
                    self.displayBoard()
                    self.checkForWinner()
                    self.showWinStatus()
                    self.playSound2()
                }
            }
        }
      }
    }
    
    @objc func img2Clicked(){
     // This code is for testing the GUI, will change in real game code
        if(win==0){
            if(turn == HUMAN_PLAYER && board[1] != HUMAN_PLAYER && board[1] != COMPUTER_PLAYER){
                s2.image = #imageLiteral(resourceName: "x_img.png")
                playSound1()
                board[1] = HUMAN_PLAYER
                turn = COMPUTER_PLAYER
                self.whoseTurn.text = "Computer’s Turn"
                print("TTT_ACTIVITY: ")
                displayBoard()
                checkForWinner()
                showWinStatus()
                
                if(win==0){
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5){
                        self.getComputerMove()
                        self.turn = self.HUMAN_PLAYER
                        self.whoseTurn.text = "Human's Turn"
                        self.displayBoard()
                        self.checkForWinner()
                        self.showWinStatus()
                        self.playSound2()
                    }
                }
            }
        }
    }
    
    @objc func img3Clicked(){
     // This code is for testing the GUI, will change in real game code
        if(win==0){
            if(turn == HUMAN_PLAYER && board[2] != HUMAN_PLAYER && board[2] != COMPUTER_PLAYER){
                s3.image = #imageLiteral(resourceName: "x_img.png")
                playSound1()
                board[2] = HUMAN_PLAYER
                turn = COMPUTER_PLAYER
                self.whoseTurn.text = "Computer’s Turn"
                print("TTT_ACTIVITY: ")
                displayBoard()
                checkForWinner()
                showWinStatus()
                
                if(win==0){
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5){
                        self.getComputerMove()
                        self.turn = self.HUMAN_PLAYER
                        self.whoseTurn.text = "Human's Turn"
                        self.displayBoard()
                        self.checkForWinner()
                        self.showWinStatus()
                        self.playSound2()
                    }
                }
            }
        }
    }
    
    @objc func img4Clicked(){
     // This code is for testing the GUI, will change in real game code
        if(win==0){
            if(turn == HUMAN_PLAYER && board[3] != HUMAN_PLAYER && board[3] != COMPUTER_PLAYER){
                s4.image = #imageLiteral(resourceName: "x_img.png")
                playSound1()
                board[3] = HUMAN_PLAYER
                turn = COMPUTER_PLAYER
                self.whoseTurn.text = "Computer’s Turn"
                print("TTT_ACTIVITY: ")
                displayBoard()
                checkForWinner()
                showWinStatus()
                
                if(win==0){
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5){
                        self.getComputerMove()
                        self.turn = self.HUMAN_PLAYER
                        self.whoseTurn.text = "Human's Turn"
                        self.displayBoard()
                        self.checkForWinner()
                        self.showWinStatus()
                        self.playSound2()
                    }
                }
            }
          }
    }
    
    @objc func img5Clicked(){
     // This code is for testing the GUI, will change in real game code
        if(win==0){
            if(turn == HUMAN_PLAYER && board[4] != HUMAN_PLAYER && board[4] != COMPUTER_PLAYER){
                s5.image = #imageLiteral(resourceName: "x_img.png")
                playSound1()
                board[4] = HUMAN_PLAYER
                turn = COMPUTER_PLAYER
                self.whoseTurn.text = "Computer’s Turn"
                print("TTT_ACTIVITY: ")
                displayBoard()
                checkForWinner()
                showWinStatus()
                
                if(win==0){
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5){
                        self.getComputerMove()
                        self.turn = self.HUMAN_PLAYER
                        self.whoseTurn.text = "Human's Turn"
                        self.displayBoard()
                        self.checkForWinner()
                        self.showWinStatus()
                        self.playSound2()
                    }
                }
            }
        }
    }
    
    @objc func img6Clicked(){
     // This code is for testing the GUI, will change in real game code
        if(win==0){
            if(turn == HUMAN_PLAYER && board[5] != HUMAN_PLAYER && board[5] != COMPUTER_PLAYER){
                s6.image = #imageLiteral(resourceName: "x_img.png")
                playSound1()
                board[5] = HUMAN_PLAYER
                turn = COMPUTER_PLAYER
                self.whoseTurn.text = "Computer’s Turn"
                print("TTT_ACTIVITY: ")
                displayBoard()
                checkForWinner()
                showWinStatus()
                
                if(win==0){
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5){
                        self.getComputerMove()
                        self.turn = self.HUMAN_PLAYER
                        self.whoseTurn.text = "Human's Turn"
                        self.displayBoard()
                        self.checkForWinner()
                        self.showWinStatus()
                        self.playSound2()
                    }
                }
            }
        }
    }
    
    @objc func img7Clicked(){
     // This code is for testing the GUI, will change in real game code
        if(win==0){
            if(turn == HUMAN_PLAYER && board[6] != HUMAN_PLAYER && board[6] != COMPUTER_PLAYER){
                s7.image = #imageLiteral(resourceName: "x_img.png")
                playSound1()
                board[6] = HUMAN_PLAYER
                turn = COMPUTER_PLAYER
                self.whoseTurn.text = "Computer’s Turn"
                print("TTT_ACTIVITY: ")
                displayBoard()
                checkForWinner()
                showWinStatus()
                
                if(win==0){
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5){
                        self.getComputerMove()
                        self.turn = self.HUMAN_PLAYER
                        self.whoseTurn.text = "Human's Turn"
                        self.displayBoard()
                        self.checkForWinner()
                        self.showWinStatus()
                        self.playSound2()
                    }
                }
            }
        }
    }
    
    @objc func img8Clicked(){
     // This code is for testing the GUI, will change in real game code
        if(win==0){
            if(turn == HUMAN_PLAYER && board[7] != HUMAN_PLAYER &&  board[7] != COMPUTER_PLAYER){
                s8.image = #imageLiteral(resourceName: "x_img.png")
                playSound1()
                board[7] = HUMAN_PLAYER
                turn = COMPUTER_PLAYER
                self.whoseTurn.text = "Computer’s Turn"
                print("TTT_ACTIVITY: ")
                displayBoard()
                checkForWinner()
                showWinStatus()
                
                if(win==0){
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5){
                        self.getComputerMove()
                        self.turn = self.HUMAN_PLAYER
                        self.whoseTurn.text = "Human's Turn"
                        self.displayBoard()
                        self.checkForWinner()
                        self.showWinStatus()
                        self.playSound2()
                    }
                }
            }
        }
    }
    
    @objc func img9Clicked(){
     // This code is for testing the GUI, will change in real game code
        if(win==0){
            if(turn == HUMAN_PLAYER &&  board[8] != HUMAN_PLAYER &&  board[8] != COMPUTER_PLAYER){
                s9.image = #imageLiteral(resourceName: "x_img.png")
                playSound1()
                board[8] = HUMAN_PLAYER
                turn = COMPUTER_PLAYER
                self.whoseTurn.text = "Computer’s Turn"
                print("TTT_ACTIVITY: ")
                displayBoard()
                checkForWinner()
                showWinStatus()
                
                if(win==0){
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5){
                        self.getComputerMove()
                        self.turn = self.HUMAN_PLAYER
                        self.whoseTurn.text = "Human's Turn"
                        self.displayBoard()
                        self.checkForWinner()
                        self.showWinStatus()
                        self.playSound2()
                    }
                }
            }
        }
    }
    func displayBoard()
    {
        print()
        print(board[0] + " | " + board[1] + " | " + board[2])
        print("-----------")
        print(board[3] + " | " + board[4] + " | " + board[5])
        print("-----------")
        print(board[6] + " | " + board[7] + " | " + board[8]);
        print();
    }
    
    func showWinStatus(){
        if (win==1){
            print("It's a tie")
            whoseTurn.text="Tie!!!"
            Globals.sharedManager.gameTies = Globals.sharedManager.gameTies + 1
        }
        else if(win==2){
            print(HUMAN_PLAYER + "wins")
            whoseTurn.text="Human Wins !!!"
            Globals.sharedManager.humanWins = Globals.sharedManager.humanWins + 1
        }
        else if(win==3){
            print(COMPUTER_PLAYER + "wins")
            whoseTurn.text="Computer Wins !!!"
            Globals.sharedManager.computerWins = Globals.sharedManager.computerWins + 1
        }
        else{
            print("There is a logical problem")
        }
    }
    
    func getComputerMove(){
        
        if(gameDifficulty == 1){
            repeat{
                move = Int.random(in: 0..<9)
            }
            while(board[move] == HUMAN_PLAYER || board[move] == COMPUTER_PLAYER)
           
            board[move]=COMPUTER_PLAYER
            mBoardArray[move].image=#imageLiteral(resourceName: "o_img.png")
        }
        
        if(gameDifficulty == 2){
            for index in 0...8{
                if(board[index] != HUMAN_PLAYER && board[index] != COMPUTER_PLAYER){
                    let curr = board[index]
                    board[index]=HUMAN_PLAYER
                    checkForWinner()
                    if(win==2){
                        board[index]=COMPUTER_PLAYER
                        mBoardArray[index].image=#imageLiteral(resourceName: "o_img.png")
                        return
                    }
                    else{
                        board[index]=curr
                    }
                }
            }
            repeat{
                move = Int.random(in: 0..<9)
            }
            while(board[move] == HUMAN_PLAYER || board[move] == COMPUTER_PLAYER)
       
            board[move]=COMPUTER_PLAYER
            mBoardArray[move].image=#imageLiteral(resourceName: "o_img.png")
        }

        if(gameDifficulty == 3){
            for index in 0...8{
                if(board[index] != HUMAN_PLAYER && board[index] != COMPUTER_PLAYER){
                    let curr = board[index]
                    board[index]=COMPUTER_PLAYER
                    checkForWinner()
    
                    if(win == 3){
                        mBoardArray[index].image=#imageLiteral(resourceName: "o_img.png")
                        return
                    }
                    else{
                        board[index]=curr
                    }
                }
            }
            for index in 0...8{
                if(board[index] != HUMAN_PLAYER && board[index] != COMPUTER_PLAYER){
                    let curr = board[index]
                    board[index]=HUMAN_PLAYER
                    checkForWinner()
                    if(win==2){
                        board[index]=COMPUTER_PLAYER
                        mBoardArray[index].image=#imageLiteral(resourceName: "o_img.png")
                        return
                    }
                    else{
                    board[index]=curr
                    }
                }
            }
            repeat{
                move = Int.random(in: 0..<9)
            }
            while(board[move] == HUMAN_PLAYER || board[move] == COMPUTER_PLAYER)
       
            board[move]=COMPUTER_PLAYER
            mBoardArray[move].image=#imageLiteral(resourceName: "o_img.png")
        }
    }
    
    func checkForWinner(){
        for index in stride(from: 0, through: 6, by: 3){
            if(board[index] == HUMAN_PLAYER && board[index+1] == HUMAN_PLAYER && board[index+2] == HUMAN_PLAYER){
               win = 2
                return
            }
            if(board[index] == COMPUTER_PLAYER && board[index+1] == COMPUTER_PLAYER && board[index+2] == COMPUTER_PLAYER){
               win = 3
                return
            }
        }
        for index in 0...2{
            if(board[index] == HUMAN_PLAYER && board[index+3] == HUMAN_PLAYER && board[index+6] == HUMAN_PLAYER){
                win = 2
                return
            }
            if(board[index] == COMPUTER_PLAYER && board[index+3] == COMPUTER_PLAYER && board[index+6] == COMPUTER_PLAYER){
                win = 3
                return
            }
        }
        if(board[0] == HUMAN_PLAYER && board[4] == HUMAN_PLAYER && board[8] == HUMAN_PLAYER || board[2] == HUMAN_PLAYER && board[4] == HUMAN_PLAYER && board[6] == HUMAN_PLAYER){
            win = 2
            return
        }
        if(board[0] == COMPUTER_PLAYER && board[4] == COMPUTER_PLAYER && board[8] == COMPUTER_PLAYER || board[2] == COMPUTER_PLAYER && board[4] == COMPUTER_PLAYER && board[6] == COMPUTER_PLAYER){
            win = 3
            return
        }
        
        for index in 0...8{
            if(board[index] != HUMAN_PLAYER && board[index] != COMPUTER_PLAYER){
                win = 0
                return
            }
        }
        win=1
  }

    func playSound1(){
        let path = Bundle.main.path(forResource: "swish.mp3", ofType: nil)!
        let url = URL(fileURLWithPath: path)
        
        do{
            sound1 = try AVAudioPlayer(contentsOf: url)
            sound1?.play()
        }
        catch{
            print("Couldn't Load File")
        }
    }
    
    func playSound2(){
        let path = Bundle.main.path(forResource: "sword.mp3", ofType: nil)!
        let url = URL(fileURLWithPath: path)
        
        do{
            sound2 = try AVAudioPlayer(contentsOf: url)
            sound2?.play()
        }
        catch{
            print("Couldn't Load File")
        }
    }
    
    func setDifficulty(difficulty:Int){
        var level:String
        
        gameDifficulty = difficulty
        
        switch difficulty{
            case 1:
                level = "Easy"
                
            case 2:
                level = "Medium"
       
            case 3:
                level = "Hard"
       
            default:
                level = "Easy"
                print("Difficulty is set to easy")
        }
        
        print("TTT_ACTIVITY: Game Difficulty Level Now Set To:" + level)
    }
}
